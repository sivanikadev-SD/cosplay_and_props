/* 
   Anime & Cosplay Prop Maker - Main Javascript
   Theme Management, RTL, and Interactive Elements
*/

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initScrollNavbar();
    initAnimations();
    initFormValidation();
    initRTLEvents();
    initLoadingStates();
});

/* 1. Theme (Dark/Light Mode) & System Preference */
function initTheme() {
    const html = document.documentElement;
    const themeBtn = document.getElementById('theme-toggle');
    const systemPref = window.matchMedia('(prefers-color-scheme: dark)');
    const savedTheme = localStorage.getItem('theme');

    const setTheme = (theme) => {
        html.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        updateThemeIcon(theme);
    };

    // Initial detection
    if (savedTheme) {
        setTheme(savedTheme);
    } else if (systemPref.matches) {
        setTheme('dark');
    } else {
        // Explicitly default to dark for this specific site's aesthetic
        setTheme('dark');
    }

    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const current = html.getAttribute('data-theme');
            setTheme(current === 'dark' ? 'light' : 'dark');
        });
    }

    // Listen for system changes
    systemPref.addListener((e) => {
        if (!localStorage.getItem('theme')) {
            setTheme(e.matches ? 'dark' : 'light');
        }
    });
}

function updateThemeIcon(theme) {
    const icon = document.querySelector('#theme-toggle i');
    if (icon) {
        icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
    }
}

/* 2. Navbar Scroll Behavior */
function initScrollNavbar() {
    const nav = document.querySelector('.navbar-custom');
    if (!nav) return;

    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
    });
}

/* 3. RTL Toggle (Manual or detection) */
function initRTLEvents() {
    const rtlBtn = document.getElementById('rtl-toggle');
    if (!rtlBtn) return;

    rtlBtn.addEventListener('click', () => {
        const isRTL = document.documentElement.getAttribute('dir') === 'rtl';
        document.documentElement.setAttribute('dir', isRTL ? 'ltr' : 'rtl');
        rtlBtn.innerText = isRTL ? 'RTL' : 'LTR';
    });
}

/* 4. Smooth Fade-in Animations (Intersection Observer) */
function initAnimations() {
    const revealItems = document.querySelectorAll('.reveal');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });

    revealItems.forEach(item => observer.observe(item));
}

/* 5. Client-Side Form Validation */
function initFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
}

/* 6. Loading States (Skeleton Loaders) */
function initLoadingStates() {
    window.addEventListener('load', () => {
        const skeletons = document.querySelectorAll('.skeleton-wrapper');
        skeletons.forEach(s => s.classList.add('loaded'));

        // Hide initial overlay if exists
        const loader = document.getElementById('page-loader');
        if (loader) {
            loader.style.opacity = '0';
            setTimeout(() => loader.style.display = 'none', 500);
        }
    });
}
